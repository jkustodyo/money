<?php

include 'includes/libs/admin_footer_pages.module.php';